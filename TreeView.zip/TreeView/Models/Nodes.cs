﻿using System.ComponentModel.DataAnnotations;

namespace TreeView.Models
{
    public class Nodes
    {
        [Key]
        public int nodeId { get; set; }

        [Display(Name = "Node Name")]
        [Required(ErrorMessage = "Node name can't be Empty!")]
        public string? nodeName { get; set; }

        [Required(ErrorMessage = "Parent node can't be Empty!")]
        public int parentNodeId { get; set; }

        [Display(Name = "Parent Node Name")]
        public string? parentNodeName { get; set; }
        public bool isActive { get; set; }
        public DateTime startDate { get; set; }
    }
}
