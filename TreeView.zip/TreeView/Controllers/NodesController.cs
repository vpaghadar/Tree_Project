﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using System.Xml.Linq;
using TreeView.Helpers;
using TreeView.Models;

namespace TreeView.Controllers
{
    public class NodesController : Controller
    {
        private readonly IConfiguration _config;
        private readonly NodeHelper nh;

        public NodesController(IConfiguration config)
        {
            _config = config;
            nh = new NodeHelper(_config);
        }

        // GET: NodesController
        public ActionResult Index()
        {
            List<Nodes> nodesList = nh.GetAll();
            return View(nodesList);
        }

        // GET: NodesController/Create
        public ActionResult Add()
        {
            ViewBag.activenodes = nh.GetAllActiveParentNodes();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Add(Nodes node)
        {
            nh.Add(node);
            return RedirectToAction("Add", "Nodes");
        }

        // GET: NodesController/Edit/5
        public ActionResult Edit(int id)
        {
            ViewBag.activenodes = nh.GetAllActiveNodes();
            Nodes node = nh.GetOne(id);
            return View(node);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Nodes node)
        {
            nh.Edit(node);
            return RedirectToAction("Index", "Nodes");
        }

        // POST: NodesController/Delete/5
        public ActionResult Delete(int id)
        {
            nh.Delete(id);
            return RedirectToAction("Index", "Nodes");
        }

        public ActionResult TreeView()
        {
            List<Nodes> nodes = nh.GetAllActiveNodes();
            ViewBag.activenodes = JsonSerializer.Serialize(nodes);
            return View();
        }
    }
}
