﻿using System.Data;
using System.Text;
using Npgsql;
using TreeView.Models;

namespace TreeView.Helpers
{
    public class NodeHelper
    {
        private readonly IConfiguration _config;
        private readonly NpgsqlConnection conn;
        public NodeHelper(IConfiguration configuration)
        {
            _config = configuration;
            conn = new NpgsqlConnection(_config.GetValue<string>("ConnectionStrings:TreeViewContext"));
        }
        public List<Nodes> GetAll()
        {
            List<Nodes> nodeList = new List<Nodes>();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("SELECT");
            sb.AppendLine("     node.c_nodeid,");
            sb.AppendLine("     node.c_nodename,");
            sb.AppendLine("     COALESCE(parent.c_nodename, '/') AS c_parentnodename,");
            sb.AppendLine("     node.c_isactive");
            sb.AppendLine("FROM t_nodes AS node");
            sb.AppendLine("LEFT JOIN t_nodes AS parent ON node.c_parentnodeid = parent.c_nodeid;");
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sb.ToString();
                conn.Open();
                NpgsqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Nodes node = new Nodes();
                    node.nodeId = Convert.ToInt32(dr["c_nodeid"]);
                    node.nodeName = Convert.ToString(dr["c_nodename"]);
                    node.parentNodeName = Convert.ToString(dr["c_parentnodename"]);
                    node.isActive = Convert.ToBoolean(dr["c_isactive"]);
                    nodeList.Add(node);
                }
                dr.Close();
                conn.Close();
            }
            return nodeList;
        }

        public List<Nodes> GetAllActiveParentNodes()
        {
            List<Nodes> activeParentNodeList = new List<Nodes>();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("SELECT");
            sb.AppendLine("     node.c_nodeid AS c_parentnodeid,");
            sb.AppendLine("     node.c_nodename AS c_parentnodename");
            sb.AppendLine("FROM t_nodes AS node");
            sb.AppendLine("WHERE node.c_isactive = true;");
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sb.ToString();
                conn.Open();
                NpgsqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Nodes node = new Nodes();
                    node.parentNodeId = Convert.ToInt32(dr["c_parentnodeid"]);
                    node.parentNodeName = Convert.ToString(dr["c_parentnodename"]);
                    activeParentNodeList.Add(node);
                }
                dr.Close();
                conn.Close();
            }
            return activeParentNodeList;
        }

        public List<Nodes> GetAllActiveNodes()
        {
            List<Nodes> activeNodeList = new List<Nodes>();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("SELECT");
            sb.AppendLine("     node.c_nodeid,");
            sb.AppendLine("     node.c_nodename,");
            sb.AppendLine("     node.c_parentnodeid");
            sb.AppendLine("FROM t_nodes AS node");
            sb.AppendLine("WHERE node.c_isactive = true");
            sb.AppendLine("ORDER BY c_parentnodeid ASC;");
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sb.ToString();
                conn.Open();
                NpgsqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Nodes node = new Nodes();
                    node.nodeId = Convert.ToInt32(dr["c_nodeid"]);
                    node.nodeName = Convert.ToString(dr["c_nodename"]);
                    node.parentNodeId = Convert.ToInt32(dr["c_parentnodeid"]);
                    activeNodeList.Add(node);
                }
                dr.Close();
                conn.Close();
            }
            return activeNodeList;
        }

        public Nodes GetOne(int id)
        {
            Nodes node = new Nodes();
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("SELECT");
            sb.AppendLine("     node.c_nodeid,");
            sb.AppendLine("     node.c_nodename,");
            sb.AppendLine("     node.c_parentnodeid,");
            sb.AppendLine("     COALESCE(parent.c_nodename, '/') AS c_parentnodename,");
            sb.AppendLine("     node.c_isactive");
            sb.AppendLine("FROM t_nodes AS node");
            sb.AppendLine("LEFT JOIN t_nodes AS parent ON node.c_parentnodeid = parent.c_nodeid");
            sb.AppendLine("WHERE node.c_nodeid = @c_nodeid;");
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sb.ToString();
                cmd.Parameters.AddWithValue("@c_nodeid", id);
                conn.Open();
                NpgsqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    node.nodeId = Convert.ToInt32(dr["c_nodeid"]);
                    node.nodeName = Convert.ToString(dr["c_nodename"]);
                    node.parentNodeId = Convert.ToInt32(dr["c_parentnodeid"]);
                    node.parentNodeName = Convert.ToString(dr["c_parentnodename"]);
                    node.isActive = Convert.ToBoolean(dr["c_isactive"]);
                }
                dr.Close();
                conn.Close();
            }
            return node;
        }

        public void Add(Nodes node)
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "INSERT INTO t_nodes(c_nodename, c_parentnodeid, c_isactive) VALUES(@c_nodename, @c_parentnodeid, @c_isactive);";
                cmd.Parameters.AddWithValue("@c_nodename", node.nodeName);
                cmd.Parameters.AddWithValue("@c_parentnodeid", node.parentNodeId);
                cmd.Parameters.AddWithValue("@c_isactive", node.isActive);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void Edit(Nodes node)
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "UPDATE t_nodes SET c_nodename = @c_nodename, c_parentnodeid = @c_parentnodeid, c_isactive = @c_isactive WHERE c_nodeid = @c_nodeid;";
                cmd.Parameters.AddWithValue("@c_nodeid", node.nodeId);
                cmd.Parameters.AddWithValue("@c_nodename", node.nodeName);
                cmd.Parameters.AddWithValue("@c_parentnodeid", node.parentNodeId);
                cmd.Parameters.AddWithValue("@c_isactive", node.isActive);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }

        public void Delete(int id)
        {
            using (NpgsqlCommand cmd = new NpgsqlCommand())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "DELETE FROM t_nodes WHERE c_nodeid = @c_nodeid;";
                cmd.Parameters.AddWithValue("@c_nodeid", id);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }
    }
}
