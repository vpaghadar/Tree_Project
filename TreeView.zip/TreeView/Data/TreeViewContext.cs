﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TreeView.Models;

namespace TreeView.Data
{
    public class TreeViewContext : DbContext
    {
        public TreeViewContext (DbContextOptions<TreeViewContext> options)
            : base(options)
        {
        }

        public DbSet<TreeView.Models.Nodes> Nodes { get; set; } = default!;
    }
}
